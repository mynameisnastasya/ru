# Визуальные варианты на компонентах 21st.dev

Пять переработок сайта. Контент, структура, форма, диагностика и FAQ везде идентичны базовому `../index.html` — меняется только визуальный и motion-слой.

## Просмотр

Из папки «Сайт личного бренда»:

```bash
python3 -m http.server 4173
```

Затем открыть `http://127.0.0.1:4173/variants-21st/<папка>/`.

## Варианты

1. **`01-aurora-botanical`** — тёмный hero и CTA с «северным сиянием» в лесной палитре.
   Компоненты: Aurora Background (manuarora700), Flip Words (manuarora700), Card Spotlight (manuarora700), Animated Shiny Text (dillionverma).
2. **`02-spotlight-atelier`** — полностью тёмная «галерея», свет как главный герой.
   Компоненты: Spotlight New (manuarora700), Floating Navbar (manuarora700), Glowing Effect (manuarora700), Spotlight Cursor (uilayout).
3. **`03-editorial-cut`** — светлая журнальная типографика в движении.
   Компоненты: Vertical Cut Reveal (danielpetho), Text Reveal (dillionverma), Timeline (manuarora700), Marquee (dillionverma), Scroll Progress (ibelick).
4. **`04-shader-forest`** — генеративный canvas-«туман» в hero и финальном CTA.
   Компоненты: Shader Background (minhxthanh), Beams Background (kokonutd), Word Rotate (dillionverma), Card Spotlight (manuarora700).
5. **`05-3d-tactile`** — светлый, всё интерактивное реагирует наклоном и глубиной.
   Компоненты: 3D Card (manuarora700), Sticky Scroll Reveal (manuarora700), Morphing Cursor (jatin-yadav05), Bento Grid (kokonutd), Typewriter Effect (manuarora700).

## Технические гарантии (все варианты)

- vanilla HTML/CSS/JS, без сборщиков, CDN и внешних зависимостей;
- анимации только `transform`/`opacity`; canvas — rAF, DPR ≤ 1.5, пауза при скрытой вкладке;
- на мобильных тяжёлые эффекты (canvas, tilt, кастомные курсоры, sticky-сцены) отключены или заменены статикой;
- `prefers-reduced-motion: reduce` отключает весь декоративный motion;
- кастомные курсоры — только `@media (pointer: fine)`;
- сохранены доступность (aria, skip-link, focus-visible) и весь базовый JS.

Исходники адаптированных компонентов лежат в `../references/21st-components/`.
