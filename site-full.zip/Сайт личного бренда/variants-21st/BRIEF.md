# Бриф для сборки вариантов (21st.dev адаптации)

## База
Исходный сайт: `/Users/nastasya/Desktop/Nastasya/Сайт личного бренда/`
- `index.html` — контент и структура. СОХРАНИТЬ ПОЛНОСТЬЮ: все секции, тексты, форму, диагностику, FAQ, порядок блоков, id-якоря, aria-атрибуты.
- `styles.css` — исходная визуальная система (можно читать для сверки, но CSS каждого варианта пишется заново).
- `script.js` — база JS: мобильное меню, диагностика, reveal, форма, FAQ. Эту функциональность обязан сохранить каждый вариант.
- Исходники компонентов 21st.dev: `references/21st-components/*.tsx` — читать и адаптировать технику на vanilla.

## Палитра и типографика (неизменны)
```
--cream: #f2f0e9; --cream-deep: #dedfd5; --paper: #f9f8f3;
--ink: #111712; --muted: #62685f; --line: rgba(17,23,18,.17);
--forest: #294632; --forest-deep: #121f16; --sage: #aab79b;
--brass: #8d9672; --white: #fbfaf5;
--display: "Iowan Old Style", Baskerville, Georgia, serif;
--sans: Inter, ui-sans-serif, -apple-system, sans-serif;
```

## Пути ассетов
Из папки варианта картинки доступны как `../../assets/dark-leaves.jpg`, `../../assets/leaf-macro.jpg`, `../../assets/forest-texture.jpg`.

## Каждый вариант = папка с тремя файлами
`index.html`, `styles.css`, `script.js`. Без сборщиков, без CDN-зависимостей, без Tailwind, без React. Всё vanilla.

## Технические требования (обязательные)
1. Вся функциональность из базового `script.js` сохраняется (меню, диагностика, форма, FAQ, reveal).
2. `@media (prefers-reduced-motion: reduce)` — отключить декоративные анимации, оставить контент видимым.
3. Кастомные курсоры: только `@media (pointer: fine)`, на тач — нативный курсор; не ломать клики (pointer-events: none на слое курсора).
4. Тяжёлые фоны (canvas/WebGL): пауза при `document.hidden`, `requestAnimationFrame`, cap DPR до 1.5, на мобильных (<768px) заменять статичным CSS-градиентом.
5. Анимации только на `transform`/`opacity` (кроме фоновых канвасов). Никаких layout-triggering анимаций.
6. Мобильная версия: проверить, что hero-коллаж, сетки, навигация складываются в колонку; sticky-эффекты на мобильных упрощаются или отключаются.
7. Reveal-анимации через IntersectionObserver, элементы без JS остаются видимыми (класс `js` на html, как в базе).
8. Семантика и доступность: не терять aria, focus-visible, skip-link.
9. В `<head>` каждого варианта — комментарий со списком использованных компонентов 21st.dev (автор/слаг).
