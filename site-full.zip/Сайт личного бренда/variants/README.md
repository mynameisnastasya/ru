# Визуальные варианты сайта Настасьи

Откройте любой `index.html` в браузере или через локальный сервер.

1. `01-glassmorphism` — Glassmorphism & Radial Glow: стекло, мягкие свечения, cursor-follow glow, premium SaaS/atelier.
2. `02-cinematic-parallax` — Cinematic Parallax Scroll: sticky hero, параллакс, кинематографичный скролл, глубина.
3. `03-interactive-3d` — Interactive 3D: 3D tilt hero, объёмные карточки, tactile hover, spatial UI.
4. `04-gradient-aurora` — Aurora Gradient Waves: живые органические градиенты, glow, background beams, атмосферность.
5. `05-editorial-minimal` — Editorial Minimal Ultra: строгая журнальная эстетика, крупная типографика, минимальные дорогие микроанимации.

Все варианты сохраняют структуру и содержание основной страницы. Меняются только визуальная система и motion-слой.
